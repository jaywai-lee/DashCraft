(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@tanstack/query-devtools/build/DevtoolsComponent-qqrUzsOa.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_b7245806._.js",
  "static/chunks/node_modules_@tanstack_query-devtools_build_DevtoolsComponent-qqrUzsOa_a3d1dcf9.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@tanstack/query-devtools/build/DevtoolsComponent-qqrUzsOa.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent-DO16dsQd.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_109e987b._.js",
  "static/chunks/d4b1c_modules_@tanstack_query-devtools_build_DevtoolsPanelComponent-DO16dsQd_a3d1dcf9.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent-DO16dsQd.js [app-client] (ecmascript)");
    });
});
}),
]);