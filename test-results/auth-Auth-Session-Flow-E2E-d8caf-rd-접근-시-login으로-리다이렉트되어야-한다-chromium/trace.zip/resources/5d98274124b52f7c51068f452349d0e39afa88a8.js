(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/shared/lib/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
const createClient = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://tbijqubwsnmnabaksept.supabase.co"), ("TURBOPACK compile-time value", "sb_publishable_z26TvsF3lOz0kcr9VHJZHg_bClKwcuP"));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/dashboard-grid/api/dashboardRepository.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dashboardRepository",
    ()=>dashboardRepository
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/client.ts [app-client] (ecmascript)");
;
const dashboardRepository = {
    async fetchWidgets () {
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { data, error } = await supabase.from("widgets").select("*").order("sort_order", {
            ascending: true
        });
        if (error) throw error;
        return data !== null && data !== void 0 ? data : [];
    },
    async insertWidget (widget) {
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { data, error } = await supabase.from("widgets").insert(widget).select().single();
        if (error) throw error;
        return data;
    },
    async updateWidget (widgetId, updates) {
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { data, error } = await supabase.from("widgets").update(updates).eq("widget_id", widgetId).select().single();
        if (error) throw error;
        return data;
    },
    async deleteWidget (widgetId) {
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { error } = await supabase.from("widgets").delete().eq("widget_id", widgetId);
        if (error) throw error;
    },
    async reorderWidgets (widgetIds) {
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { error } = await supabase.rpc("reorder_widgets", {
            p_widget_ids: widgetIds
        });
        if (error) throw error;
    },
    async deleteAllWidgets () {
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { error } = await supabase.from("widgets").delete().neq("widget_id", "");
        if (error) throw error;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/dashboard-grid/config/widgets.config.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_CLOCK_CONFIG",
    ()=>DEFAULT_CLOCK_CONFIG,
    "WIDGET_CONFIG_MAP",
    ()=>WIDGET_CONFIG_MAP,
    "WIDGET_OPTIONS",
    ()=>WIDGET_OPTIONS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-client] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$todo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListTodo$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/list-todo.js [app-client] (ecmascript) <export default as ListTodo>");
;
const WIDGET_CONFIG_MAP = {
    todo: {
        type: "todo",
        title: "할 일 목록",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$todo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ListTodo$3e$__["ListTodo"]
    },
    clock: {
        type: "clock",
        title: "시계 & 뽀모도로",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"]
    },
    dday: {
        type: "dday",
        title: "D-Day",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"]
    },
    memo: {
        type: "memo",
        title: "메모",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"]
    }
};
const WIDGET_OPTIONS = Object.values(WIDGET_CONFIG_MAP);
_c = WIDGET_OPTIONS;
const DEFAULT_CLOCK_CONFIG = {
    workDuration: 1500,
    breakDuration: 300,
    isSoundEnabled: true,
    isNotificationEnabled: true
};
var _c;
__turbopack_context__.k.register(_c, "WIDGET_OPTIONS");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/config/queryKeys.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "queryKeys",
    ()=>queryKeys
]);
const queryKeys = {
    widgets: {
        all: [
            "widgets"
        ],
        list: ()=>[
                ...queryKeys.widgets.all,
                "list"
            ]
    },
    todos: {
        all: [
            "todos"
        ],
        byWidget: (widgetId)=>[
                ...queryKeys.todos.all,
                "widget",
                widgetId
            ]
    },
    memos: {
        all: [
            "memos"
        ],
        byWidget: (widgetId)=>[
                ...queryKeys.memos.all,
                "widget",
                widgetId
            ]
    },
    ddays: {
        all: [
            "ddays"
        ],
        byWidget: (widgetId)=>[
                ...queryKeys.ddays.all,
                "widget",
                widgetId
            ]
    },
    schedules: {
        all: [
            "schedules"
        ],
        range: (startDate, endDate)=>[
                ...queryKeys.schedules.all,
                "range",
                startDate,
                endDate
            ]
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/shared/lib/react-query/optimisticHelper.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createOptimisticMutation",
    ()=>createOptimisticMutation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
;
function createOptimisticMutation(param) {
    let { queryClient, queryKey, mutationFn, updateCache, errorMessage = "요청 처리 실패" } = param;
    return {
        mutationKey: queryKey,
        mutationFn,
        onMutate: async (variables)=>{
            await queryClient.cancelQueries({
                queryKey
            });
            const previousData = queryClient.getQueryData(queryKey);
            queryClient.setQueryData(queryKey, (old)=>updateCache(old, variables));
            return {
                previousData
            };
        },
        onError: (err, _variables, context)=>{
            if ((context === null || context === void 0 ? void 0 : context.previousData) !== undefined) {
                queryClient.setQueryData(queryKey, context.previousData);
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(errorMessage, {
                description: err.message
            });
        },
        onSettled: ()=>{
            if (queryClient.isMutating({
                mutationKey: queryKey
            }) === 1) {
                queryClient.invalidateQueries({
                    queryKey
                });
            }
        }
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/dashboard-grid/lib/generateWidgetTitle.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "generateNextWidgetTitle",
    ()=>generateNextWidgetTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/dashboard-grid/config/widgets.config.ts [app-client] (ecmascript)");
;
const generateNextWidgetTitle = (type, existingWidgets, defaultTitle)=>{
    const config = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WIDGET_CONFIG_MAP"][type];
    const baseTitle = defaultTitle || (config === null || config === void 0 ? void 0 : config.title) || "위젯";
    const sameTypeWidgets = existingWidgets.filter((w)=>w.type === type);
    if (sameTypeWidgets.length === 0) {
        return "".concat(baseTitle, " 1");
    }
    let maxNum = 0;
    const numRegex = new RegExp("^".concat(baseTitle, "\\s*(\\d+)$"));
    sameTypeWidgets.forEach((w)=>{
        const trimmedTitle = w.title.trim();
        const match = trimmedTitle.match(numRegex);
        if (match) {
            const num = parseInt(match[1], 10);
            if (!isNaN(num) && num > maxNum) {
                maxNum = num;
            }
        } else if (trimmedTitle === baseTitle) {
            if (maxNum < 1) {
                maxNum = 1;
            }
        }
    });
    return "".concat(baseTitle, " ").concat(maxNum + 1);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/widgets/dashboard-grid/api/useDashboardQuery.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAddWidgetMutation",
    ()=>useAddWidgetMutation,
    "useDeleteWidgetMutation",
    ()=>useDeleteWidgetMutation,
    "useReorderWidgetsMutation",
    ()=>useReorderWidgetsMutation,
    "useResetDashboardMutation",
    ()=>useResetDashboardMutation,
    "useUpdateWidgetMutation",
    ()=>useUpdateWidgetMutation,
    "useWidgetsQuery",
    ()=>useWidgetsQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/dashboard-grid/api/dashboardRepository.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/dashboard-grid/config/widgets.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/config/queryKeys.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$react$2d$query$2f$optimisticHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/react-query/optimisticHelper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$lib$2f$generateWidgetTitle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/dashboard-grid/lib/generateWidgetTitle.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
const useWidgetsQuery = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(),
        queryFn: {
            "useWidgetsQuery.useQuery": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dashboardRepository"].fetchWidgets()
        }["useWidgetsQuery.useQuery"]
    });
};
_s(useWidgetsQuery, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
const useAddWidgetMutation = ()=>{
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(),
        mutationFn: {
            "useAddWidgetMutation.useMutation": async (param)=>{
                let { type, title: inputTitle, color = "default", layout_w = 1, widgetId } = param;
                const targetWidgetId = widgetId || crypto.randomUUID();
                var _queryClient_getQueryData;
                const currentWidgets = (_queryClient_getQueryData = queryClient.getQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list())) !== null && _queryClient_getQueryData !== void 0 ? _queryClient_getQueryData : [];
                const otherWidgets = currentWidgets.filter({
                    "useAddWidgetMutation.useMutation.otherWidgets": (w)=>w.widget_id !== targetWidgetId
                }["useAddWidgetMutation.useMutation.otherWidgets"]);
                const config = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WIDGET_CONFIG_MAP"][type];
                var _config_title;
                const baseTitle = (_config_title = config === null || config === void 0 ? void 0 : config.title) !== null && _config_title !== void 0 ? _config_title : "위젯";
                const finalTitle = inputTitle || (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$lib$2f$generateWidgetTitle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateNextWidgetTitle"])(type, otherWidgets, baseTitle);
                const maxSortOrder = otherWidgets.length > 0 ? Math.max(...otherWidgets.map({
                    "useAddWidgetMutation.useMutation": (w)=>w.sort_order
                }["useAddWidgetMutation.useMutation"])) : 0;
                const nextSortOrder = maxSortOrder + 1;
                const isClock = type === "clock";
                const clockConfig = isClock ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CLOCK_CONFIG"] : {};
                return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dashboardRepository"].insertWidget({
                    widget_id: targetWidgetId,
                    type,
                    title: finalTitle,
                    color,
                    layout_w,
                    layout_h: 1,
                    layout_x: 0,
                    layout_y: 0,
                    sort_order: nextSortOrder,
                    config: clockConfig
                });
            }
        }["useAddWidgetMutation.useMutation"],
        onMutate: {
            "useAddWidgetMutation.useMutation": async (newWidgetParams)=>{
                await queryClient.cancelQueries({
                    queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list()
                });
                const targetWidgetId = newWidgetParams.widgetId || crypto.randomUUID();
                newWidgetParams.widgetId = targetWidgetId;
                var _queryClient_getQueryData;
                const previousWidgets = (_queryClient_getQueryData = queryClient.getQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list())) !== null && _queryClient_getQueryData !== void 0 ? _queryClient_getQueryData : [];
                const config = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WIDGET_CONFIG_MAP"][newWidgetParams.type];
                var _config_title;
                const baseTitle = (_config_title = config === null || config === void 0 ? void 0 : config.title) !== null && _config_title !== void 0 ? _config_title : "위젯";
                if (!newWidgetParams.title) {
                    newWidgetParams.title = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$lib$2f$generateWidgetTitle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generateNextWidgetTitle"])(newWidgetParams.type, previousWidgets, baseTitle);
                }
                const finalTitle = newWidgetParams.title;
                const maxSortOrder = previousWidgets.length > 0 ? Math.max(...previousWidgets.map({
                    "useAddWidgetMutation.useMutation": (w)=>w.sort_order
                }["useAddWidgetMutation.useMutation"])) : 0;
                var _newWidgetParams_color, _newWidgetParams_layout_w;
                const optimisticWidget = {
                    id: crypto.randomUUID(),
                    user_id: "",
                    widget_id: targetWidgetId,
                    type: newWidgetParams.type,
                    title: finalTitle,
                    color: (_newWidgetParams_color = newWidgetParams.color) !== null && _newWidgetParams_color !== void 0 ? _newWidgetParams_color : "default",
                    layout_w: (_newWidgetParams_layout_w = newWidgetParams.layout_w) !== null && _newWidgetParams_layout_w !== void 0 ? _newWidgetParams_layout_w : 1,
                    layout_h: 1,
                    layout_x: 0,
                    layout_y: 0,
                    sort_order: maxSortOrder + 1,
                    config: newWidgetParams.type === "clock" ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_CLOCK_CONFIG"] : {},
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString()
                };
                queryClient.setQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(), [
                    ...previousWidgets,
                    optimisticWidget
                ]);
                return {
                    previousWidgets
                };
            }
        }["useAddWidgetMutation.useMutation"],
        onError: {
            "useAddWidgetMutation.useMutation": (err, _variables, context)=>{
                if (context === null || context === void 0 ? void 0 : context.previousWidgets) {
                    queryClient.setQueryData(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(), context.previousWidgets);
                }
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("위젯 추가 실패", {
                    description: err.message
                });
            }
        }["useAddWidgetMutation.useMutation"],
        onSettled: {
            "useAddWidgetMutation.useMutation": ()=>{
                if (queryClient.isMutating({
                    mutationKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list()
                }) === 1) {
                    queryClient.invalidateQueries({
                        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list()
                    });
                }
            }
        }["useAddWidgetMutation.useMutation"]
    });
};
_s1(useAddWidgetMutation, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const useUpdateWidgetMutation = ()=>{
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$react$2d$query$2f$optimisticHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createOptimisticMutation"])({
        queryClient,
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(),
        mutationFn: {
            "useUpdateWidgetMutation.useMutation": (param)=>{
                let { widgetId, title, color, layout_w, config } = param;
                return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dashboardRepository"].updateWidget(widgetId, {
                    ...title !== undefined && {
                        title
                    },
                    ...color !== undefined && {
                        color
                    },
                    ...layout_w !== undefined && {
                        layout_w
                    },
                    ...config !== undefined && {
                        config: config
                    }
                });
            }
        }["useUpdateWidgetMutation.useMutation"],
        updateCache: {
            "useUpdateWidgetMutation.useMutation": function() {
                let oldWidgets = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], { widgetId, title, color, layout_w, config } = arguments.length > 1 ? arguments[1] : void 0;
                return oldWidgets.map({
                    "useUpdateWidgetMutation.useMutation": (w)=>{
                        if (w.widget_id !== widgetId) return w;
                        return {
                            ...w,
                            ...title !== undefined && {
                                title
                            },
                            ...color !== undefined && {
                                color
                            },
                            ...layout_w !== undefined && {
                                layout_w
                            },
                            ...config !== undefined && {
                                config: {
                                    ...w.config,
                                    ...config
                                }
                            }
                        };
                    }
                }["useUpdateWidgetMutation.useMutation"]);
            }
        }["useUpdateWidgetMutation.useMutation"],
        errorMessage: "위젯 설정 변경 실패"
    }));
};
_s2(useUpdateWidgetMutation, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const useDeleteWidgetMutation = ()=>{
    _s3();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$react$2d$query$2f$optimisticHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createOptimisticMutation"])({
        queryClient,
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(),
        mutationFn: {
            "useDeleteWidgetMutation.useMutation": (widgetId)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dashboardRepository"].deleteWidget(widgetId)
        }["useDeleteWidgetMutation.useMutation"],
        updateCache: {
            "useDeleteWidgetMutation.useMutation": function() {
                let oldWidgets = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], widgetId = arguments.length > 1 ? arguments[1] : void 0;
                return oldWidgets.filter({
                    "useDeleteWidgetMutation.useMutation": (w)=>w.widget_id !== widgetId
                }["useDeleteWidgetMutation.useMutation"]);
            }
        }["useDeleteWidgetMutation.useMutation"],
        errorMessage: "위젯 삭제 실패"
    }));
};
_s3(useDeleteWidgetMutation, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const useReorderWidgetsMutation = ()=>{
    _s4();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$react$2d$query$2f$optimisticHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createOptimisticMutation"])({
        queryClient,
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(),
        mutationFn: {
            "useReorderWidgetsMutation.useMutation": (widgetIds)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dashboardRepository"].reorderWidgets(widgetIds)
        }["useReorderWidgetsMutation.useMutation"],
        updateCache: {
            "useReorderWidgetsMutation.useMutation": function() {
                let oldWidgets = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], widgetIds = arguments.length > 1 ? arguments[1] : void 0;
                const widgetMap = new Map(oldWidgets.map({
                    "useReorderWidgetsMutation.useMutation": (w)=>[
                            w.widget_id,
                            w
                        ]
                }["useReorderWidgetsMutation.useMutation"]));
                return widgetIds.map({
                    "useReorderWidgetsMutation.useMutation": (id, index)=>{
                        const item = widgetMap.get(id);
                        if (!item) return null;
                        return {
                            ...item,
                            sort_order: index + 1
                        };
                    }
                }["useReorderWidgetsMutation.useMutation"]).filter({
                    "useReorderWidgetsMutation.useMutation": (w)=>w !== null
                }["useReorderWidgetsMutation.useMutation"]);
            }
        }["useReorderWidgetsMutation.useMutation"],
        errorMessage: "위젯 순서 변경 실패"
    }));
};
_s4(useReorderWidgetsMutation, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const useResetDashboardMutation = ()=>{
    _s5();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$react$2d$query$2f$optimisticHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createOptimisticMutation"])({
        queryClient,
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$config$2f$queryKeys$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queryKeys"].widgets.list(),
        mutationFn: {
            "useResetDashboardMutation.useMutation": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$dashboardRepository$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dashboardRepository"].deleteAllWidgets()
        }["useResetDashboardMutation.useMutation"],
        updateCache: {
            "useResetDashboardMutation.useMutation": ()=>[]
        }["useResetDashboardMutation.useMutation"],
        errorMessage: "대시보드 초기화 실패"
    }));
};
_s5(useResetDashboardMutation, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/command-palette/model/useCommandPaletteStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCommandPaletteStore",
    ()=>useCommandPaletteStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useCommandPaletteStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
        isOpen: false,
        setIsOpen: (isOpen)=>set({
                isOpen
            }),
        toggle: ()=>set((state)=>({
                    isOpen: !state.isOpen
                }))
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/command-palette/model/useCommandPalette.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCommandPalette",
    ()=>useCommandPalette
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$command$2d$palette$2f$model$2f$useCommandPaletteStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/command-palette/model/useCommandPaletteStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const useCommandPalette = ()=>{
    _s();
    const { isOpen, setIsOpen, toggle } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$command$2d$palette$2f$model$2f$useCommandPaletteStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCommandPaletteStore"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCommandPalette.useEffect": ()=>{
            const handleKeyDown = {
                "useCommandPalette.useEffect.handleKeyDown": (e)=>{
                    if (!pathname.startsWith("/dashboard")) return;
                    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
                        e.preventDefault();
                        toggle();
                    }
                    if (e.key === "Escape" && isOpen) {
                        setIsOpen(false);
                    }
                }
            }["useCommandPalette.useEffect.handleKeyDown"];
            window.addEventListener("keydown", handleKeyDown);
            return ({
                "useCommandPalette.useEffect": ()=>window.removeEventListener("keydown", handleKeyDown)
            })["useCommandPalette.useEffect"];
        }
    }["useCommandPalette.useEffect"], [
        isOpen,
        toggle,
        setIsOpen,
        pathname
    ]);
    return {
        isOpen,
        setIsOpen,
        toggle
    };
};
_s(useCommandPalette, "44Iz3rJPzIDrHcd8Nqvj2VLqA9A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$command$2d$palette$2f$model$2f$useCommandPaletteStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCommandPaletteStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/dashboard-filter/model/useFilterStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectIsFilterActive",
    ()=>selectIsFilterActive,
    "useFilterStore",
    ()=>useFilterStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useFilterStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
        isOpen: false,
        searchQuery: "",
        selectedWidgetType: "all",
        todoStatus: "all",
        datePreset: "all",
        startDate: null,
        endDate: null,
        toggleFilter: ()=>set((state)=>({
                    isOpen: !state.isOpen
                })),
        setSearchQuery: (searchQuery)=>set({
                searchQuery
            }),
        setSelectedWidgetType: (selectedWidgetType)=>set({
                selectedWidgetType
            }),
        setTodoStatus: (todoStatus)=>set({
                todoStatus
            }),
        setDatePreset: (datePreset)=>set({
                datePreset,
                ...datePreset !== "custom" && {
                    startDate: null,
                    endDate: null
                }
            }),
        setCustomDateRange: (startDate, endDate)=>set({
                datePreset: "custom",
                startDate,
                endDate
            }),
        resetFilter: ()=>set({
                searchQuery: "",
                selectedWidgetType: "all",
                todoStatus: "all",
                datePreset: "all",
                startDate: null,
                endDate: null
            })
    }));
const selectIsFilterActive = (state)=>state.searchQuery !== "" || state.selectedWidgetType !== "all" || state.todoStatus !== "all" || state.datePreset !== "all";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/command-palette/ui/CommandPalette.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CommandPalette",
    ()=>CommandPalette
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$useDashboardQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/dashboard-grid/api/useDashboardQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$command$2d$palette$2f$model$2f$useCommandPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/command-palette/model/useCommandPalette.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$dashboard$2d$filter$2f$model$2f$useFilterStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/dashboard-filter/model/useFilterStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/widgets/dashboard-grid/config/widgets.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/cmdk/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/filter.js [app-client] (ecmascript) <export default as Filter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const CommandPalette = ()=>{
    _s();
    const { isOpen, setIsOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$command$2d$palette$2f$model$2f$useCommandPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCommandPalette"])();
    const { data: widgets = [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$useDashboardQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWidgetsQuery"])();
    const addWidgetMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$useDashboardQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAddWidgetMutation"])();
    const { setSelectedWidgetType, setSearchQuery } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$dashboard$2d$filter$2f$model$2f$useFilterStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterStore"])();
    if (!isOpen) return null;
    const handleAddWidget = (type)=>{
        const config = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WIDGET_CONFIG_MAP"][type];
        if (!config) return;
        addWidgetMutation.mutate({
            type: config.type,
            title: config.title,
            layout_w: 1,
            widgetId: crypto.randomUUID()
        });
        setIsOpen(false);
    };
    const handleFocusWidget = (widgetId)=>{
        setIsOpen(false);
        const element = document.getElementById("widget-".concat(widgetId));
        if (element) {
            element.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });
            element.classList.add("ring-2", "ring-primary");
            setTimeout(()=>element.classList.remove("ring-2", "ring-primary"), 2000);
        }
    };
    const handleFilter = (type)=>{
        setSelectedWidgetType(type);
        setIsOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-start justify-center pt-[15vh] px-4",
        onClick: ()=>setIsOpen(false),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            onClick: (e)=>e.stopPropagation(),
            className: "w-full max-w-xl bg-popover text-popover-foreground rounded-xl border shadow-2xl overflow-hidden",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"], {
                label: "Command Palette",
                className: "w-full",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center border-b px-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                className: "w-4 h-4 mr-2 shrink-0 opacity-50"
                            }, void 0, false, {
                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Input, {
                                autoFocus: true,
                                onValueChange: (val)=>setSearchQuery(val),
                                placeholder: "위젯 검색, 추가 또는 명령어 입력... (Esc로 닫기)",
                                className: "flex h-12 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
                            }, void 0, false, {
                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                lineNumber: 68,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                        lineNumber: 66,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].List, {
                        className: "max-h-[300px] overflow-y-auto p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Empty, {
                                className: "py-6 text-center text-sm text-muted-foreground",
                                children: "검색 결과가 없습니다."
                            }, void 0, false, {
                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            widgets.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Group, {
                                heading: "현재 대시보드 위젯 이동",
                                className: "px-2 py-1.5 text-xs text-muted-foreground font-semibold",
                                children: widgets.map((widget)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Item, {
                                        value: "widget-".concat(widget.title, "-").concat(widget.widget_id),
                                        onSelect: ()=>handleFocusWidget(widget.widget_id),
                                        className: "flex items-center gap-2 px-2.5 py-2 rounded-md text-sm cursor-pointer data-[selected='true']:bg-primary/10 data-[selected='true']:text-primary aria-selected:bg-primary/10 aria-selected:text-primary transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                                className: "w-4 h-4 text-muted-foreground"
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 93,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: widget.title
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 94,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "ml-auto text-xs opacity-50",
                                                children: widget.type
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 95,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, widget.widget_id, true, {
                                        fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                        lineNumber: 87,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                lineNumber: 82,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Group, {
                                heading: "새 위젯 추가",
                                className: "px-2 py-1.5 text-xs text-muted-foreground font-semibold",
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WIDGET_OPTIONS"].map((item)=>{
                                    const Icon = item.icon;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Item, {
                                        value: "add-".concat(item.type, "-").concat(item.title),
                                        onSelect: ()=>handleAddWidget(item.type),
                                        className: "flex items-center gap-2 px-2.5 py-2 rounded-md text-sm cursor-pointer data-[selected='true']:bg-primary/10 data-[selected='true']:text-primary aria-selected:bg-primary/10 aria-selected:text-primary transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                className: "w-4 h-4 text-primary shrink-0"
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 116,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: item.title
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 117,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                className: "w-3.5 h-3.5 ml-auto opacity-50"
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 118,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, item.type, true, {
                                        fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                        lineNumber: 110,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0));
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                lineNumber: 103,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Group, {
                                heading: "필터",
                                className: "px-2 py-1.5 text-xs text-muted-foreground font-semibold",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Item, {
                                        value: "filter-all-widgets",
                                        onSelect: ()=>handleFilter("all"),
                                        className: "flex items-center gap-2 px-2.5 py-2 rounded-md text-sm cursor-pointer data-[selected='true']:bg-primary/10 data-[selected='true']:text-primary aria-selected:bg-primary/10 aria-selected:text-primary transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__["Filter"], {
                                                className: "w-4 h-4 text-muted-foreground"
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 133,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "모든 위젯 보기"
                                            }, void 0, false, {
                                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                lineNumber: 134,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                        lineNumber: 128,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$config$2f$widgets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WIDGET_OPTIONS"].map((item)=>{
                                        const Icon = item.icon;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cmdk$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"].Item, {
                                            value: "filter-".concat(item.type, "-").concat(item.title),
                                            onSelect: ()=>handleFilter(item.type),
                                            className: "flex items-center gap-2 px-2.5 py-2 rounded-md text-sm cursor-pointer data-[selected='true']:bg-primary/10 data-[selected='true']:text-primary aria-selected:bg-primary/10 aria-selected:text-primary transition-colors",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                    className: "w-4 h-4 text-primary shrink-0"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                    lineNumber: 146,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        item.title,
                                                        " 위젯만 보기"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                                    lineNumber: 147,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, "filter-".concat(item.type), true, {
                                            fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                            lineNumber: 140,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0));
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                                lineNumber: 124,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
                lineNumber: 65,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
            lineNumber: 61,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/features/command-palette/ui/CommandPalette.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CommandPalette, "O5tqbyYfyIR1B9NrhJASWK3Efsg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$command$2d$palette$2f$model$2f$useCommandPalette$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCommandPalette"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$useDashboardQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWidgetsQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$widgets$2f$dashboard$2d$grid$2f$api$2f$useDashboardQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAddWidgetMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$dashboard$2d$filter$2f$model$2f$useFilterStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterStore"]
    ];
});
_c = CommandPalette;
var _c;
__turbopack_context__.k.register(_c, "CommandPalette");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/providers/ThemeProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
function ThemeProvider(param) {
    let { children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/app/providers/ThemeProvider.tsx",
        lineNumber: 7,
        columnNumber: 10
    }, this);
}
_c = ThemeProvider;
var _c;
__turbopack_context__.k.register(_c, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/features/memo-widget/api/memoKeepalive.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "flushMemoKeepalive",
    ()=>flushMemoKeepalive,
    "setAccessToken",
    ()=>setAccessToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
let accessToken = null;
const setAccessToken = (token)=>{
    accessToken = token;
};
function flushMemoKeepalive(widgetId, content, highlight) {
    if (!accessToken) return;
    void fetch("".concat(("TURBOPACK compile-time value", "https://tbijqubwsnmnabaksept.supabase.co"), "/rest/v1/memos?on_conflict=user_id,widget_id"), {
        method: "POST",
        keepalive: true,
        headers: {
            "Content-Type": "application/json",
            apikey: ("TURBOPACK compile-time value", "sb_publishable_z26TvsF3lOz0kcr9VHJZHg_bClKwcuP"),
            Authorization: "Bearer ".concat(accessToken),
            Prefer: "resolution=merge-duplicates,return=minimal"
        },
        body: JSON.stringify({
            widget_id: widgetId,
            content,
            highlight
        })
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/providers/AuthSync.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthSync",
    ()=>AuthSync
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/shared/lib/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$memo$2d$widget$2f$api$2f$memoKeepalive$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/memo-widget/api/memoKeepalive.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function AuthSync() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthSync.useEffect": ()=>{
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$shared$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            let currentUserId = null;
            supabase.auth.getSession().then({
                "AuthSync.useEffect": (param)=>{
                    let { data } = param;
                    var _data_session, _data_session1;
                    var _data_session_access_token;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$memo$2d$widget$2f$api$2f$memoKeepalive$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setAccessToken"])((_data_session_access_token = (_data_session = data.session) === null || _data_session === void 0 ? void 0 : _data_session.access_token) !== null && _data_session_access_token !== void 0 ? _data_session_access_token : null);
                    var _data_session_user_id;
                    currentUserId = (_data_session_user_id = (_data_session1 = data.session) === null || _data_session1 === void 0 ? void 0 : _data_session1.user.id) !== null && _data_session_user_id !== void 0 ? _data_session_user_id : null;
                }
            }["AuthSync.useEffect"]);
            const { data: { subscription } } = supabase.auth.onAuthStateChange({
                "AuthSync.useEffect": (event, session)=>{
                    var _session_access_token;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$memo$2d$widget$2f$api$2f$memoKeepalive$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setAccessToken"])((_session_access_token = session === null || session === void 0 ? void 0 : session.access_token) !== null && _session_access_token !== void 0 ? _session_access_token : null);
                    var _session_user_id;
                    const nextUserId = (_session_user_id = session === null || session === void 0 ? void 0 : session.user.id) !== null && _session_user_id !== void 0 ? _session_user_id : null;
                    const userChanged = currentUserId !== null && nextUserId !== null && currentUserId !== nextUserId;
                    if (event === "SIGNED_OUT" || userChanged) {
                        queryClient.clear();
                        localStorage.removeItem("dashcraft-clock-runtime-v1");
                    }
                    if (event === "SIGNED_OUT" && window.location.pathname.match(/^\/(dashboard|calendar|settings)/)) {
                        window.location.href = "/login";
                    }
                    currentUserId = nextUserId;
                }
            }["AuthSync.useEffect"]);
            return ({
                "AuthSync.useEffect": ()=>subscription.unsubscribe()
            })["AuthSync.useEffect"];
        }
    }["AuthSync.useEffect"], [
        queryClient
    ]);
    return null;
}
_s(AuthSync, "aixO0mo1bdM1nWLRolCdKzppx/I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"]
    ];
});
_c = AuthSync;
var _c;
__turbopack_context__.k.register(_c, "AuthSync");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/providers/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2d$devtools$2f$build$2f$modern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query-devtools/build/modern/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$providers$2f$ThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/providers/ThemeProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$providers$2f$AuthSync$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/providers/AuthSync.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function Providers(param) {
    let { children } = param;
    _s();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "Providers.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        staleTime: 1000 * 60 * 5,
                        gcTime: 1000 * 60 * 30,
                        retry: {
                            "Providers.useState": (failureCount, error)=>{
                                const pgError = error;
                                if ((pgError === null || pgError === void 0 ? void 0 : pgError.code) === "42501" || (pgError === null || pgError === void 0 ? void 0 : pgError.code) === "23514") {
                                    return false;
                                }
                                return failureCount < 2;
                            }
                        }["Providers.useState"],
                        refetchOnWindowFocus: true
                    }
                }
            })
    }["Providers.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$providers$2f$ThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
                attribute: "class",
                defaultTheme: "system",
                enableSystem: true,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$providers$2f$AuthSync$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthSync"], {}, void 0, false, {
                        fileName: "[project]/src/app/providers/index.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this),
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/providers/index.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2d$devtools$2f$build$2f$modern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReactQueryDevtools"], {
                initialIsOpen: false
            }, void 0, false, {
                fileName: "[project]/src/app/providers/index.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/providers/index.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_s(Providers, "QjNQhDEU58Z2uKtQ2f8MVIP9pXU=");
_c = Providers;
var _c;
__turbopack_context__.k.register(_c, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_a506f0b8._.js.map