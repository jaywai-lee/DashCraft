(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_89e497cd._.js",
  "static/chunks/src_b23afdb3._.js"
],
    source: "dynamic"
});
