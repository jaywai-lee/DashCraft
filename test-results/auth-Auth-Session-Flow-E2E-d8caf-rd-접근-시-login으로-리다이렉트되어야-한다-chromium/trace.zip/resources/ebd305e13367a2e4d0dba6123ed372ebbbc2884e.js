(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ee53e3fe._.css",
  "static/chunks/node_modules_@tanstack_query-devtools_build_d8cd77ee._.js",
  "static/chunks/node_modules_next_2505f17a._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_bc4db492._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_@tanstack_query-devtools_build_a8cfcf87._.js",
  "static/chunks/node_modules_47acd64a._.js",
  "static/chunks/src_a506f0b8._.js"
],
    source: "dynamic"
});
